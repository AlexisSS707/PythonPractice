"""
Math Tricks Lab
3/9/2015
"""

#part 2
num = input("Pick a number, any number:") 
print "Your number is", num
def trick2(num):
    return num * 3
print "Your number times 3 is:", trick2(num)

print "Add 45 to your number."
def trick3(num1):
    return num * 3 +45
print "Your number plus fortyfive:", trick3(num)

print "Multiple your answer by two."
def trick3(num2):
    return (num * 3 +45) * 2
print "The number times two is:", trick3(num)

print "Divide the answer by six."
def trick4(num3):
    return ((num * 3 +45) * 2) / 6
print "The number divided by six is:", trick4(num)

print "Subtract the number from the oringinal number."
def trick5(num4):
    return (((num * 3 +45) * 2) / 6) - num
print "The original answer subtracted by the number is:", trick5(num)