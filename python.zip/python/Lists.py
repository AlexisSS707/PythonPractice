"""
Lists 4/27/15
"""

print "Example 1"
#create an empty list
myList = []
print "Empty List"
print myList

print "\n\nExample 2"
# Create a list with stuff in it
print "Lists with items in it"
coworkers = ["Sarah", "Matt", "Paula", "Sophie"]
print coworkers

print "\n\nExample 3"
#Prints all the prices within the list
price = [32.23, 12.25, 56.38, 77.55, 39.00]
print price

print "\n\nExample 4"
#print the original list
print "Changing item at index 1"
print coworkers

#change the item at index 1
coworkers[1] = "James"
print coworkers

print "\n\nExample 5"
#print the items in the list
print "Items at index 0 and 2"
print coworkers[0], coworkers[2]

print "\n\nExample 6"
myList = [2, 1, 31, 7, 5, 12, 8]

#Print the items in the list
print "Using math operators to get items in a list"
print myList[1 + 3]
print myList[7 - 3]
print myList[11 / 2]

print "\n\nExample 7"
students = ['bernice', 'aaron', 'cody']

for student in students:
    print ("Hello," + student.title() + "!")
    #Notice the output for Example 7
    #The names become capitalized to title()