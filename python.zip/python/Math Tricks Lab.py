"""
Math Tricks Lab
3/3/2015
"""

#Part one
num = input("Pick a number, any number under 10:") 
print "Your number is", num
def trick1(num):
   return num * 2
print "Your number times two is:", trick1(num)

print "Add six to your number"
def trick2(num1):
    return num * 2  + 6
print "Your number times two:", trick2(num)

print "Divide the answer by two"
def trick3(num2):
    return (num * 2  + 6) / 2
print "The answer divided by two is:", trick3(num)

print "Subtract number by your beginning number"
def trick4(num3):
    return ((num * 2  + 6) / 2) - num
print "The final answer is:", trick4(num)


