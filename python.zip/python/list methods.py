"""
List Methods 4/29/15
"""

print "Original  List of coworkers list"
coworkers = ["Sarah", "Matt", "Sophie", "James", "Tammy", "Robert"]
print coworkers

print "\n\nExample Append"
#Add a name to coworker
coworkers.append("Trevor")
print "Append method"
print coworkers

print "\n\nReset the coworkers list"
print "Reset coworkers"
coworkers = ["Sarah", "Matt", "Sophie", "James", "Tammy" , "Robert"]
print coworkers

print "\n\nExampe Insert"
#Add a name to coworkers at index 1
coworkers.insert(1, "Lawrence")
print "Insert method"
print coworkers

print "\n\nExample Remove Data"
#Remove a name from coworkers
print "Remove the name Sarah"
coworkers.remove("Sarah")
print coworkers

print "\n\nRemove an item from an idex"
#Remove a name from coworkers
print "Pop the item at index 1"
coworkers.pop(1)
print coworkers

print "\n\nReset the coworkers list"
print "Reset coworkers"
coworkers = ["Sarah", "Matt", "Sophie", "James", "Tammy", "Robert"]
print coworkers

print "\n\nUse of Len method to determine the length of a list"
#Length of coworkers
print "Len mehtod"
print len(coworkers)