x = input ("How many seconds?")
while x >=0:
    print x
    x -=1
    