"""
Ifs Lab March 25, 2015
"""

grade = input("What is the grade?")
if grade <= 59:
    print "E"
else:
    if grade >= 60 and grade <= 69:
            print "D"
    else:    
            if grade >= 70 and grade <=79:
                print "C"
            else:
                if grade >=80 and grade <=89:
                    print "B"
                else:
                    if grade >= 90 and grade <=100:
                        print "A"
                    else:
                        print "Congrats! You have an A and extra credit!!!"
