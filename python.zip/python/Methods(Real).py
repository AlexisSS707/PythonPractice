#Example one

print "Bad Example"
def sayLotsOStuff():
    print "Lots Of"
print"Stuff"

sayLotsOStuff()

print "\n\nGood Example"
def sayLotsOStuff3():
    print "Lots Of"
    print "Stuff"
    
    sayLotsOStuff
    
#Example 2

print "\n\nExample 2 - Nothing will happen"

def sayNothing():
    pass
    
sayNothing()

#Example Three

print "\n\nExample 3"
def cubeIt (num):
    return num * num * num
    
print cubeIt(4)