"""
Fors Examples March 27, 2015
"""

print "Example 1 print the output 4 times"
for x in range(4):
    print "This is your first example."
    
print "\n\nExample 2 prints numbers from 0 to 6 since the range is 7"
for z in range(7):
    print z
    
print "\n\nExample 3 prints every oter number (even numbers) from 22 to 27"
for r in range (22, 28, 2):
    print r
    
print "\n\nExample 4 prints the letters for the words SPRING BREAK in each line of output"
for c in "Spring Break is coming soon.":
    print c
    
print "\n\nExample 5 prints the letters up to the letters up to the letter v; Do you know what break does?"
word = "Computer Problem Solving Class"
for w in word:
    if w == "v":
        break
    print w