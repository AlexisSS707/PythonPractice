"""
While Loop March 31, 2015
"""

#Example 1
print "Example 1"
answer = "yes"

while answer == "yes":
    answer = raw_input("Keep Looping?")
    
#Example 2
print "\n\nExample 2"
x = 0

while x < 5:
    print x
    x += 1
    
#Example 3
print "\n\nExamle 3"
count = 0
while (count < 9):
    print "The count is:", count
    count = count + 1
print "Good bye!"

#Example 4
print "\n\nExample 4"
i = 2
while (i < 100):
    j = 2
    while (j <= (i/j)):
        if not (i%j): break
        j = j +1
    if (j > i/j) : print i, "is prime"
    i = i +1
print "Two more to go!"

#Example 5
print "Example 5"
for x in range(3):
    print "x is", str(x)
    for y in range(2):
        print "y is", str(y)
    print
    
#Example 6
print "\n\nExample 6"
for x in range(3):
    for y in range(3):
        print "(", str(x), ",", str(y), ")",
        print "Please let Mrs. Hamiltion know when you are done with the assignment for your grade."