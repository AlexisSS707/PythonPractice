#If Exercise March 17 2015

print "Ifs Examle 1"

num  = 97
if num >= 90:
    print "Hello"
print "World"

print"\n\nIfs Example 2"

num = 50
if num >= 90:
    print "Hello"
print "World"

print "\n\nIfs Example 3"

num = 150
print (num >= 90)

print "\n\nIfs Example 4"
weight = input("How many pounds does your suitcase weigh? ")
if weight > 50:
    print "There is a $25 charge for luggage that heavy."
print "Thank you for your business."