"""
Logical Operators 3/19/15
"""

print "Logical Operators"

x = 50
y = 100

if x > 400 and y < 300:
    print "Upper right"
elif x < 400 and y > 300:
    print "Upper left"
else:
    print "Bottom"
    
print "\nRelational Operators"
print "True or False"
print (True or False)

print "\nTrue and False"
print (True and False)

print "\nnot True"
print (not True)