# Part One

name = raw_input("What is your name?")
print "My name is", name
print "Your name is", name

age = input("How old are you?")
print "My age is", age
print "Your age is", age

currentyear = input("What year is it?")
print "The year is", currentyear

birthyear = currentyear - age
prioryear = birthyear - 1
print "You were born in", birthyear,
print"or", prioryear

#Part Two

x = input("Enter an integer for x:")
y = input("Enter an integer for y:")
z = input("Enter a decimal for z:")

product = x * y
print "The product of x and y is:", product

product2 = x * y * z
print "The product of x, y, and z:", product2

x2 = x % 2
print "Integer remainder of x divided by 2 is", x2
y2 = y % 2
print "Integer remainder of y divided by 2 is", y2
z2 = z % 2
print "Decimal remainder of z divided by 3 is", z2