"""
College Majors pt1 5/5/15
"""

#1
majors = ["library science", "accountanting", "english", "early education", "psychology", "nursing", "socialogy", "biology", "secondary education", "computer science"]
#2
majors.append("spanish")
majors.append("french")
print majors

#3
majors.insert(8, "literature")
print majors

#4
print "\n\n Welcome to Rock Bottom University!"
print "These are the official majors for Rock Bottom University!"
majors.remove("spanish")
majors.remove("accountanting")
majors.remove("early education")
print majors

"""
\n\npart 2

question = raw_input("What major would like to take in this university? ")
if question == majors:
    print "Sorry, we do not have this major. Pick another major. It may be available by September 1, 2015 because we are offering other majors then."
else:
    print "We do have this major. You need to apply by June 15, 2015 if you are a senoir in high school."
print "\nWe hope to see you here at Rock Bottom University!"
"""
question = raw_input("Look at the list. Is the major you are looking for in this list? ")
if question == ("yes"):
    print "\nThat's great! You need to apply by June 15, 2015 if you are a senoir in high school."
else:
   print "\nSorry. Check again at September 1, 2015, because other majors are being offered after that date."
   
print "\nWe hope to see you here at Rock Bottom University!"