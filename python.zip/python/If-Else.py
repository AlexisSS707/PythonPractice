"""
If-Else 3/19/15
"""

print "Example 1"
print "If-else Example"
seconds = 10
if seconds >=60:
    print "over a minute"
else:
    print "Less than a minute"
    
#Example 2
print "\n\nExample 2"
temperature = input("What is the temperature? ")
if temperature > 70:
    print "Wear shorts."
else:
    print "Wear long pants."
print "Get some exercise outside."