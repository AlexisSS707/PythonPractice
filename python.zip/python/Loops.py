"""
Loops 1 Alternate/ 1 Classwork
April 13, 2015
"""

# The player's power starts out at 5.

power = 5

#the player is allowed to keep playing as long as their power is over 0.

while power > 0:
    print "You are still playing, because your power is.", power
    #your game code would go here, which includes challanges that make it
    #    impossible to lose power
    #We can represent that by just taking away from the power
    power = power - 1
print "\nOh no, your power dropped to 0! Game over."

#classwork assignment    
strength = 5

while strength < 10:
    print "\nYour strength is.", strength
    strength +=1

print "Your strength has went to 10! Time to move up a next level in the game!"